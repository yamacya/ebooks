#MySql Database Organizer using PyQt

import sys
import os
import platform

from PyQt4.QtGui import (QMainWindow, QApplication, QFileDialog,
                         QKeySequence, QAction, QIcon, QMessageBox, QPixmap, QLabel, QTableWidgetItem, QTreeWidgetItem,
                        QTreeWidget, QAbstractItemView, QHeaderView, QPushButton)
from PyQt4.QtCore import (SIGNAL, PYQT_VERSION_STR, QT_VERSION,
                          QT_VERSION_STR, QObject, QStringList, QString, Qt)

import ui_ResourceFile

from PyQt4.QtSql import *
from Configuration import Configuration
from InsertNewEntry import *
from AboutDlg import *

from Ui_DatabaseOrganizer import Ui_MainWindow

class DatabaseOrganizer(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(DatabaseOrganizer,self).__init__(parent)
        self.setupUi(self)

        #connect flag
        self.connected = False

        #resize splitter
        sizes = [1, self.centralWidget().width()+150]
        self.splitter.setSizes(sizes)

        #context menu
        self.setContextMenuPolicy(Qt.DefaultContextMenu)

        #disconnect is disabled (there is no connection on at start up)
        self.actionDisconnect.setEnabled(False)

        #set disconnected icon (no connection on at start up)
        self.connectedLbl = QLabel()
        self.connectedLbl.setPixmap(QPixmap(":/img/img/disconnected.png"))
        self.connectedState = QLabel("<b>Disconnected</b>")
        self.statusbar.addWidget(self.connectedLbl)
        self.statusbar.addWidget(self.connectedState)

        #selection policy and resize to contents for qtablewidget
        self.databaseTable.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.databaseTable.setContextMenuPolicy(Qt.ActionsContextMenu)
        self.databaseTable.horizontalHeader().setResizeMode(QHeaderView.ResizeToContents)

        #create actions for context menu of qtablewidget
        self.addAction = QAction("&Add new entry", self.databaseTable,
                              triggered = self.callAddEntry)
        self.rmvAction = QAction("&Remove entry", self.databaseTable,
                              triggered = self.callRmvEntry)
        self.modifyAction = QAction("&Save Modification", self.databaseTable,
                              triggered = self.callSaveEntry)

        self.addAction.setEnabled(False)
        self.rmvAction.setEnabled(False)
        self.modifyAction.setEnabled(False)

        self.databaseTable.addAction(self.addAction)
        self.databaseTable.addAction(self.rmvAction)
        self.databaseTable.addAction(self.modifyAction)

        #read database information
        f = open('config.txt')
        lines = f.readlines()
        f.close()

        for x in range(0, lines.__len__()):
            lines[x] = lines[x].rstrip()
            lines[x] = lines[x].lstrip()

        self.db = QSqlDatabase.addDatabase("QMYSQL")
        self.dbIP = lines[0].split("=")[1]
        self.dbName = lines[1].split("=")[1]
        self.dbUser = lines[2].split("=")[1]
        self.dbPass = lines[3].split("=")[1]

        #connect actions
        self.connect(self.actionConnect, SIGNAL('triggered()'), self.callConnection)
        self.connect(self.actionDisconnect, SIGNAL('triggered()'), self.callDisconnection)
        self.connect(self.actionConfigureConection, SIGNAL('triggered()'), self.callConfiguration)
        self.connect(self.actionHelp, SIGNAL('triggered()'), self.callHelp)
        self.connect(self.actionAbout, SIGNAL('triggered()'), self.callAbout)

        #self.databaseTableList.doubleClicked.connect(self.tableDoubleClicked)
        self.connect(self.databaseTableList, SIGNAL('itemDoubleClicked (QTreeWidgetItem *, int)'), self.tableDoubleClicked)


        self.setWindowTitle("Database Organizer")
        self.show()

    def callConnection(self):
        self.db.setHostName(self.dbIP)
        self.db.setDatabaseName(self.dbName)
        self.db.setUserName(self.dbUser)
        self.db.setPassword(self.dbPass)

        if (self.db.open()==False):
            QMessageBox.critical(None, "Database Error", self.db.lastError().text())
            return

        query = QSqlQuery("SHOW TABLES FROM "+self.dbName)

        #add database name to qtreewidget
        item = QTreeWidgetItem()
        item.setText(0,self.dbName)
        icon = QIcon()
        icon.addPixmap(QPixmap(":/img/img/database.png"), QIcon.Normal, QIcon.Off)
        item.setIcon(0,icon)
        self.databaseTableList.addTopLevelItem(item)

        #add tables names to qtreewidget
        while (query.next()):
            subItem = QTreeWidgetItem()
            subItem.setText(0,query.value(0).toString())
            icon = QIcon()
            icon.addPixmap(QPixmap(":/img/img/table.png"), QIcon.Normal, QIcon.Off)
            subItem.setIcon(0,icon)
            item.addChild(subItem)

        item.setExpanded(True)

        self.databaseTableList.resizeColumnToContents(0)

        self.connected = True

        #connect is disabled (already connected)
        self.actionDisconnect.setEnabled(True)
        self.actionConnect.setEnabled(False)

        #set connected icon (already connected)
        self.connectedLbl.setPixmap(QPixmap(":/img/img/connected.png"))
        self.connectedState.setText("<b>Connected to: "+self.dbIP+"</b>")

    def callDisconnection(self):
        self.db.close()

        self.connected = False

        #clear tables names
        self.databaseTableList.clear()

        #clear tables entries
        self.databaseTable.clear()
        self.databaseTable.setRowCount(0)
        self.databaseTable.setColumnCount(0)

        #disconnect is disabled (db closed)
        self.actionDisconnect.setEnabled(False)
        self.actionConnect.setEnabled(True)

        #set disconnected icon (db closed)
        self.connectedLbl.setPixmap(QPixmap(":/img/img/disconnected.png"))
        self.connectedState.setText("<b>Disconnected</b>")

        self.addAction.setEnabled(False)
        self.rmvAction.setEnabled(False)
        self.modifyAction.setEnabled(False)

    def tableDoubleClicked(self, item, column):
        if (item.text(0)!=self.dbName):

            #store actual table to use later
            self.actualTable = item.text(0)
            self.addElementsOnTable()

            self.addAction.setEnabled(True)
            self.rmvAction.setEnabled(True)
            self.modifyAction.setEnabled(True)

    def addElementsOnTable(self):
        query = QSqlQuery ("SHOW COLUMNS FROM "+self.actualTable)

        self.headers = QStringList()
        while (query.next()):
            self.headers.append(query.value(0).toString())

        self.databaseTable.setColumnCount(self.headers.__len__())
        self.databaseTable.setHorizontalHeaderLabels(self.headers)
        self.databaseTable.verticalHeader().hide()

        query = QSqlQuery ("SELECT * FROM "+self.actualTable)

        self.databaseTable.setRowCount(query.size())

        #add entries to qtablewidget
        index = 0
        while (query.next()):
            for x in range (0, self.headers.__len__()):
                self.databaseTable.setItem(index,x,QTableWidgetItem(query.value(x).toString()))
                self.databaseTable.resizeColumnToContents(x)
            index = index + 1

    def callAddEntry(self):
        dlg = InsertNewEntry(parent=self)
        dlg.exec_()

        if (dlg.okPressed):
            queryStr = "INSERT INTO "+self.actualTable+"("

            for i in range (1, self.headers.__len__()):
                if (i==self.headers.__len__()-1):
                    queryStr = queryStr+self.headers[i]+") VALUES ("
                else:
                    queryStr = queryStr+self.headers[i]+","

            for i in range (0, dlg.txtFields.__len__()):
                if (i==dlg.txtFields.__len__()-1):
                    queryStr = queryStr+"\""+dlg.txtFields[i].text()+"\");"
                else:
                    queryStr = queryStr+"\""+dlg.txtFields[i].text()+"\","

            query = QSqlQuery(queryStr)

            #clear table
            self.databaseTable.clear()
            self.databaseTable.setRowCount(0)
            self.databaseTable.setColumnCount(0)

            #add again
            self.addElementsOnTable()

    def callRmvEntry(self):
        selected = self.databaseTable.currentRow()
        selectedItems = self.databaseTable.selectedItems()
        if (selected==-1 or selectedItems.__len__()==0):
            QMessageBox.critical(None, "Remove Error", "You need to select which line you want to remove.")
        else:
            queryStr = "DELETE FROM "+self.actualTable+" WHERE "+self.headers[0]+"=\""+selectedItems[0].text()+"\";"
            query = QSqlQuery(queryStr)
            self.databaseTable.removeRow(selected)

    def callSaveEntry(self):
        for i in range (0, self.databaseTable.rowCount()):
            queryStr = "UPDATE "+self.actualTable+" SET"
            for j in range (self.databaseTable.columnCount()-1, 0, -1):
                if (j==1):
                    queryStr = queryStr+" "+self.headers[j]+"=\""+self.databaseTable.item(i,j).text()+"\""
                else:
                    queryStr = queryStr+" "+self.headers[j]+"=\""+self.databaseTable.item(i,j).text()+"\","
            queryStr = queryStr+" WHERE "+self.headers[0]+"=\""+self.databaseTable.item(i,0).text()+"\";"
            query = QSqlQuery(queryStr)

    def callConfiguration(self):
        dlg = Configuration(self)
        dlg.exec_()

        if (dlg.okPressed):

            #check if user changed something, if not, it does not need to reconnect
            if (self.dbIP != dlg.hostIPField.text() or self.dbName != dlg.dbField.text() or self.dbUser != dlg.userNameField.text() or self.dbPass != dlg.passwordField.text()):
                self.dbIP = dlg.hostIPField.text()
                self.dbName = dlg.dbField.text()
                self.dbUser = dlg.userNameField.text()
                self.dbPass = dlg.passwordField.text()
            else:
                return

            if (self.connected):
                self.callDisconnection()
                msgBox = QMessageBox()
                msgBox.setWindowTitle("Configuration Changed")
                msgBox.setText("The database configuration was changed and the connection terminated. Do you want to reconnect with the new configuration?")
                msgBox.addButton(QPushButton('Yes'), QMessageBox.YesRole)
                msgBox.addButton(QPushButton('No'), QMessageBox.NoRole)
                ret = msgBox.exec_();

                if (ret==0): #Yes
                    self.callConnection()

    def callHelp(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile('DatabaseOrganizer.chm'))

    def callAbout(self):
        dlg = AboutDlg(self)
        dlg.exec_()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DatabaseOrganizer()
    app.exec_()