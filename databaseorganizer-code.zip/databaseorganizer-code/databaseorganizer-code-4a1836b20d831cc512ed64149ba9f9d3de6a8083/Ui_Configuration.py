# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Configuration.ui'
#
# Created: Thu Nov 06 17:08:50 2014
#      by: PyQt4 UI code generator 4.11.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(345, 210)
        self.gridLayout_2 = QtGui.QGridLayout(Dialog)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.dbNameLbl = QtGui.QLabel(Dialog)
        self.dbNameLbl.setObjectName(_fromUtf8("dbNameLbl"))
        self.gridLayout_2.addWidget(self.dbNameLbl, 1, 0, 1, 1)
        self.hostIPLbl = QtGui.QLabel(Dialog)
        self.hostIPLbl.setObjectName(_fromUtf8("hostIPLbl"))
        self.gridLayout_2.addWidget(self.hostIPLbl, 0, 0, 1, 1)
        self.userNameLbl = QtGui.QLabel(Dialog)
        self.userNameLbl.setObjectName(_fromUtf8("userNameLbl"))
        self.gridLayout_2.addWidget(self.userNameLbl, 2, 0, 1, 1)
        self.passwordLbl = QtGui.QLabel(Dialog)
        self.passwordLbl.setObjectName(_fromUtf8("passwordLbl"))
        self.gridLayout_2.addWidget(self.passwordLbl, 3, 0, 1, 1)
        self.hostIPField = QtGui.QLineEdit(Dialog)
        self.hostIPField.setObjectName(_fromUtf8("hostIPField"))
        self.gridLayout_2.addWidget(self.hostIPField, 0, 1, 1, 1)
        self.dbField = QtGui.QLineEdit(Dialog)
        self.dbField.setObjectName(_fromUtf8("dbField"))
        self.gridLayout_2.addWidget(self.dbField, 1, 1, 1, 1)
        self.userNameField = QtGui.QLineEdit(Dialog)
        self.userNameField.setObjectName(_fromUtf8("userNameField"))
        self.gridLayout_2.addWidget(self.userNameField, 2, 1, 1, 1)
        self.passwordField = QtGui.QLineEdit(Dialog)
        self.passwordField.setEchoMode(QtGui.QLineEdit.Password)
        self.passwordField.setObjectName(_fromUtf8("passwordField"))
        self.gridLayout_2.addWidget(self.passwordField, 3, 1, 1, 1)
        self.okBtn = QtGui.QPushButton(Dialog)
        self.okBtn.setObjectName(_fromUtf8("okBtn"))
        self.gridLayout_2.addWidget(self.okBtn, 4, 1, 1, 1)
        self.cancelBtn = QtGui.QPushButton(Dialog)
        self.cancelBtn.setObjectName(_fromUtf8("cancelBtn"))
        self.gridLayout_2.addWidget(self.cancelBtn, 5, 1, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Configuration", None))
        self.dbNameLbl.setText(_translate("Dialog", "Database Name:", None))
        self.hostIPLbl.setText(_translate("Dialog", "Host IP:", None))
        self.userNameLbl.setText(_translate("Dialog", "Username:", None))
        self.passwordLbl.setText(_translate("Dialog", "Password:", None))
        self.okBtn.setText(_translate("Dialog", "OK", None))
        self.cancelBtn.setText(_translate("Dialog", "Cancel", None))

