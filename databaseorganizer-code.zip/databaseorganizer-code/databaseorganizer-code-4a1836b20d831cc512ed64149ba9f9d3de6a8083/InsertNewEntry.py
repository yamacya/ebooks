import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *

class InsertNewEntry(QDialog):

    def __init__(self, parent):
        super(InsertNewEntry, self).__init__(parent)

        self.gridLayout = QGridLayout()
        self.okPressed = False

        self.txtFields = []
        for i in range (1, parent.headers.__len__()):
            self.label = QLabel(parent.headers[i])
            self.txtFields.append(QLineEdit())
            self.gridLayout.addWidget(self.label,i,0)
            self.gridLayout.addWidget(self.txtFields[self.txtFields.__len__()-1],i,1)

        self.insertBtn = QPushButton("Insert")
        self.cancelBtn = QPushButton("Cancel")

        #connect buttons action
        self.cancelBtn.clicked.connect(self.reject)
        self.insertBtn.clicked.connect(self.accept)

        self.gridLayout.addWidget(self.insertBtn,i+1,1)
        self.gridLayout.addWidget(self.cancelBtn,i+2,1)
        self.setLayout(self.gridLayout)

        self.setWindowTitle("Insert new entry")

    #if ok pressed update the information on database config file
    def accept(self):
        self.okPressed = True
        QDialog.accept(self)
