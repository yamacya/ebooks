from distutils.core import setup
import py2exe

#setup(console=['DatabaseOrganizer.py'])
setup(windows=[{"script":"DatabaseOrganizer.py"}], options={"py2exe":{"includes":["sip","PyQt4.QtSql"]}})
