import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *

class AboutDlg(QDialog):

    def __init__(self, parent):
        super(AboutDlg, self).__init__(parent)

        self.message = QLabel()
        self.urlMessage = QLabel()
        self.logo = QLabel()

        self.message.setText("Developed by RochaCardoso Projects, the features are: \n\n - Connect to a database and list its tables; \n\n - Add new entry; \n\n - Remove existing entry; \n\n - Modify existing entry. \n\n")
        self.message.setAlignment(Qt.AlignHCenter)

        self.urlMessage.setText("<a href=\"mailto:cesroceng@gmail.com?subject=RemoteControl&body=Hello Cesar,\">RochaCardoso Projects</a> <br> <br> <a href=\"http://www.rochacardoso.de\">http://www.rochacardoso.de</a>")
        self.urlMessage.setOpenExternalLinks(True)
        self.urlMessage.setAlignment(Qt.AlignHCenter)

        self.logo.setPixmap(QPixmap(":/img/img/Logo.png"))
        self.logo.setAlignment(Qt.AlignHCenter)

        self.vBoxLayout = QVBoxLayout()
        self.vBoxLayout.addWidget(self.logo)
        self.vBoxLayout.addWidget(self.message)
        self.vBoxLayout.addWidget(self.urlMessage)
        self.setLayout(self.vBoxLayout)

        self.setFixedHeight(400)
        self.setFixedWidth(500)

        self.setWindowTitle("About Database Organizer")

    #if ok pressed update the information on database config file
#    def accept(self):
#        self.okPressed = True
#        QDialog.accept(self)
