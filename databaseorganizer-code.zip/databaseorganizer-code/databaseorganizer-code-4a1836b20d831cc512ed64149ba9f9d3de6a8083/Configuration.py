import sys
from PyQt4.QtCore import *
from PyQt4.QtGui import *

from Ui_Configuration import Ui_Dialog

class Configuration(QDialog,Ui_Dialog):

    def __init__(self, parent=None):
        super(Configuration, self).__init__(parent)
        self.setupUi(self)

        self.okPressed = False

        #connect buttons action
        self.cancelBtn.clicked.connect(self.reject)
        self.okBtn.clicked.connect(self.accept)

        #read database information
        f = open('config.txt')
        lines = f.readlines()
        f.close()

        for x in range(0, lines.__len__()):
            lines[x] = lines[x].rstrip()
            lines[x] = lines[x].lstrip()

        #write information on fields
        self.hostIPField.setText(lines[0].split("=")[1])
        self.dbField.setText(lines[1].split("=")[1])
        self.userNameField.setText(lines[2].split("=")[1])
        self.passwordField.setText(lines[3].split("=")[1])

    #if ok pressed update the information on database config file
    def accept(self):
        f = open("config.txt", "w")
        f.write("HOST_IP="+self.hostIPField.text()+"\n")
        f.write("HOST_NAME="+self.dbField.text()+"\n")
        f.write("USERNAME="+self.userNameField.text()+"\n")
        f.write("PASSWORD="+self.passwordField.text()+"\n")
        f.close()
        self.okPressed = True
        QDialog.accept(self)
