#!/usr/bin/env python
"""
These are the tests for the low-level module _sqlite.

They try to execute as much of the low-level _sqlite module as possible to
facilitate coverage testing with the help of gcov.
"""

import os, tempfile, unittest, re
import _sqlite
from sqlite import ProgrammingError

class lowlevelTestCases(unittest.TestCase):
    def setUp(self):
        self.filename = tempfile.mktemp()
        self.cnx = _sqlite.connect(self.filename)
        
    def tearDown(self):
        try:
            self.cnx.close()
            os.remove(self.filename)
            del self.cnx
        except AttributeError:
            pass
        except ProgrammingError:
            pass

    def CheckModuleAttributeAccess(self):
        for attr in dir(_sqlite):
            _sqlite.__dict__[attr]

    def CheckConnectionAttributes(self):
        self.cnx.begin()
        self.cnx.rollback()
        self.cnx.begin()
        self.cnx.commit()
        self.cnx.database

        try:
            self.cnx.foo = 7
            self.fail("Could set attribute. Connection object should be read-only.")
        except TypeError:
            pass

    def CheckConnectionForProgrammingError(self):
        self.cnx.close()
        os.remove(self.filename)

        self.failUnlessRaises(ProgrammingError, self.cnx.begin)
        self.failUnlessRaises(ProgrammingError, self.cnx.close)
        self.failUnlessRaises(ProgrammingError, self.cnx.commit)
        self.failUnlessRaises(ProgrammingError, self.cnx.execute, "")
        self.failUnlessRaises(ProgrammingError, self.cnx.rollback)
        self.failUnlessRaises(ProgrammingError, self.cnx.sql)

    def CheckConnectionForNumberOfArguments(self):
        self.failUnlessRaises(TypeError, self.cnx.begin, None)
        self.failUnlessRaises(TypeError, self.cnx.close, None)
        self.failUnlessRaises(TypeError, self.cnx.commit, None)
        self.failUnlessRaises(TypeError, self.cnx.execute, None, None)
        self.failUnlessRaises(TypeError, self.cnx.rollback, None)
        self.failUnlessRaises(TypeError, self.cnx.sql, None)

    def CheckConnectionDestructor(self):
        del self.cnx
        os.remove(self.filename)

    def CheckResultObject(self):
        create_statement = "create table test(id int, name varchar(20))"
        self.cnx.execute(create_statement)

        self.failUnlessEqual(create_statement, self.cnx.sql(),
            ".sql() should have been %s, was %s" % (create_statement, self.cnx.sql))
        
        self.cnx.execute("insert into test(id, name) values (4, 'foo')")
        self.cnx.execute("insert into test(id, name) values (5, 'bar')")

        res = self.cnx.execute("select * from test")
        self.failUnless(res.rowcount == 2, "Should have returned 2 rows, but was %i" % res.rowcount)

        correct_col_defs = [('id', 254, 1, 1, 0, 0, 1), ('name', 254, 3, 3, 0, 0, 1)]
        self.assertEqual(res.col_defs, correct_col_defs, 
            "col_defs should have been %s, was %s" % (repr(correct_col_defs), repr(res.col_defs)))

        correct_row_list = [('4', 'foo'), ('5', 'bar')]
        self.assertEqual(res.row_list, correct_row_list,
            "rowlist should have been %s, was %s" % (repr(correct_row_list), repr(res.row_list)))

    def CheckResultAttributes(self):
        res = self.cnx.execute("select NULL, max(4,5)")
        try:
            res.foo = 7
            
        except TypeError:
            pass

    def CheckSQLiteVersion(self):
        try:
            ver = _sqlite.sqlite_version()
        except:
            self.fail('sqlite_version() failed')
        pat = re.compile(r'\d*\.\d*\.\d*')
        if not re.match(pat,ver):
            self.fail('Incorrect sqlite_version() format, '
                'should be digits.digits.digits, was %s'%ver)


def suite():
    return unittest.makeSuite(lowlevelTestCases, "Check")

def main():
    runner = unittest.TextTestRunner()
    runner.run(suite())
    
if __name__ == "__main__":
    main()
