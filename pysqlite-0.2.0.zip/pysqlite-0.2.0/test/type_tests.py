#!/usr/bin/env python
import os, string, sys, tempfile, types, unittest
import sqlite

class MyType:
    def __init__(self, val):
        self.val = int(val)

    def _quote(self):
        return str(self.val)
    
    def __repr__(self):
        return "MyType(%s)" % self.val

    def __cmp__(self, other):
        assert(isinstance(other, MyType))
        return cmp(self.val, other.val)

class ExpectedTypes(unittest.TestCase):
    def setUp(self):
        self.filename = tempfile.mktemp()
        self.cnx = sqlite.connect(self.filename, converters={"mytype": MyType})
        self.cur = self.cnx.cursor()
        
    def tearDown(self):
        try:
            self.cnx.close()
            os.remove(self.filename)
        except AttributeError:
            pass
        except sqlite.InterfaceError:
            pass
     
    def CheckExpectedTypesStandardTypes(self):
        self.cur.execute("create table test (a, b, c)")
        self.cur.execute("insert into test(a, b, c) values (5, 6.3, 'hello')")
        self.cur.execute("pysqlite_pragma expected_types = int, float, str")
        self.cur.execute("select * from test")
        res = self.cur.fetchone()
        self.failUnless(isinstance(res.a, types.IntType),
                        "The built-in int converter didn't work.")
        self.failUnless(isinstance(res.b, types.FloatType),
                        "The built-in float converter didn't work.")
        self.failUnless(isinstance(res.c, types.StringType),
                        "The built-in string converter didn't work.")
    
    def CheckExpectedTypesStandardTypesNull(self):
        self.cur.execute("create table test (a, b, c)")
        self.cur.execute("insert into test(a, b, c) values (NULL, NULL, NULL)")
        self.cur.execute("pysqlite_pragma expected_types = int, float, str")
        self.cur.execute("select * from test")
        res = self.cur.fetchone()
        self.failUnless(res.a == None,
                        "The built-in int converter should have returned None.")
        self.failUnless(res.b == None,
                        "The built-in float converter should have returned None.")
        self.failUnless(res.c == None,
                        "The built-in string converter should have returned None.")

    def CheckExpectedTypesCustomTypes(self):
        value = MyType(10)
        self.cur.execute("create table test (a)")
        self.cur.execute("insert into test(a) values (%s)", value)
        self.cur.execute("pysqlite_pragma expected_types = mytype")
        self.cur.execute("select a from test")
        res = self.cur.fetchone()

        self.failUnless(isinstance(res.a, MyType),
                        "The converter did return the wrong type.")
        self.failUnlessEqual(value, res.a,
                             "The returned value and the inserted one are different.")

    def CheckExpectedTypesCustomTypesNull(self):
        value = None
        self.cur.execute("create table test (a)")
        self.cur.execute("insert into test(a) values (%s)", value)
        self.cur.execute("pysqlite_pragma expected_types = mytype")
        self.cur.execute("select a from test")
        res = self.cur.fetchone()

        self.failUnless(res.a == None,
                        "The converter should have returned None.")

    def CheckResetExpectedTypes(self):
        self.cur.execute("create table test (a)")
        self.cur.execute("insert into test(a) values (5)")
        self.cur.execute("pysqlite_pragma expected_types = int")
        self.cur.execute("pysqlite_pragma reset_expected_types")
        self.cur.execute("select a from test")
        res = self.cur.fetchone()
        self.assert_(isinstance(res.a, types.StringType),
                     "pragma reset_expected_types didn't reset.")

class UnicodeTestsLatin1(unittest.TestCase):
    def setUp(self):
        self.filename = tempfile.mktemp()
        self.cnx = sqlite.connect(self.filename, client_encoding=("iso-8859-1",))
        self.cur = self.cnx.cursor()
        
    def tearDown(self):
        try:
            self.cnx.close()
            os.remove(self.filename)
        except AttributeError:
            pass
        except sqlite.InterfaceError:
            pass

    def CheckGetSameBack(self):
        test_str = unicode("�sterreich", "latin1")
        self.cur.execute("create table test (a)")
        self.cur.execute("insert into test(a) values (%s)", test_str)
        self.cur.execute("pysqlite_pragma expected_types = unicode")
        self.cur.execute("select a from test")
        res = self.cur.fetchone()
        self.failUnlessEqual(type(test_str), type(res.a),
            "Something other than a Unicode string was fetched: %s"
                % (str(type(res.a))))
        self.failUnlessEqual(test_str, res.a,
            "Fetching the unicode string doesn't return the inserted one.")
 
class UnicodeTestsUtf8(unittest.TestCase):
    def setUp(self):
        self.filename = tempfile.mktemp()
        self.cnx = sqlite.connect(self.filename, client_encoding="utf-8")
        self.cur = self.cnx.cursor()
        
    def tearDown(self):
        try:
            self.cnx.close()
            os.remove(self.filename)
        except AttributeError:
            pass
        except sqlite.InterfaceError:
            pass

    def CheckGetSameBack(self):
        # PREZIDENT ROSSI'SKO' FEDERACII �sterreich
        test_str = unicode("ПРЕЗИДЕНТ РОССИЙСКОЙ ФЕДЕРАЦИИ Österreich", "utf-8")

        self.cur.execute("create table test (a)")
        self.cur.execute("insert into test(a) values (%s)", test_str)
        self.cur.execute("pysqlite_pragma expected_types = unicode")
        self.cur.execute("select a from test")
        res = self.cur.fetchone()
        self.failUnlessEqual(type(test_str), type(res.a),
            "Something other than a Unicode string was fetched: %s"
                % (str(type(res.a))))
        self.failUnlessEqual(test_str, res.a,
            "Fetching the unicode string doesn't return the inserted one.")
 
class UnicodeTestsKOI8R(unittest.TestCase):
    def setUp(self):
        self.filename = tempfile.mktemp()
        self.cnx = sqlite.connect(self.filename, client_encoding="koi8-r")
        self.cur = self.cnx.cursor()
        
    def tearDown(self):
        try:
            self.cnx.close()
            os.remove(self.filename)
        except AttributeError:
            pass
        except sqlite.InterfaceError:
            pass

    def CheckGetSameBack(self):
        # PREZIDENT ROSSI'SKO' FEDERACII
        # (President of the Russian Federation)
        test_str = unicode("��������� ���������� ���������", "koi8-r")

        self.cur.execute("create table test (a)")
        self.cur.execute("insert into test(a) values (%s)", test_str)
        self.cur.execute("pysqlite_pragma expected_types = unicode")
        self.cur.execute("select a from test")
        res = self.cur.fetchone()
        self.failUnlessEqual(type(test_str), type(res.a),
            "Something other than a Unicode string was fetched: %s"
                % (str(type(res.a))))
        self.failUnlessEqual(test_str, res.a,
            "Fetching the unicode string doesn't return the inserted one.")
 
def suite():
    expected_suite = unittest.makeSuite(ExpectedTypes, "Check")
    unicode_suite1 = unittest.makeSuite(UnicodeTestsLatin1, "Check")
    unicode_suite2 = unittest.makeSuite(UnicodeTestsUtf8, "Check")
    unicode_suite3 = unittest.makeSuite(UnicodeTestsKOI8R, "Check")
    test_suite = unittest.TestSuite((expected_suite, unicode_suite1,
                    unicode_suite2, unicode_suite3))
    return test_suite

def main():
    runner = unittest.TextTestRunner()
    runner.run(suite())
    
if __name__ == "__main__":
    main()
