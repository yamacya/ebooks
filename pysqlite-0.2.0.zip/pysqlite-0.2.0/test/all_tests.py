#!/usr/bin/env python
"""
This combines all PySQLite test suites into one big one.
"""

import unittest
import api_tests, lowlevel_tests, type_tests, userfunction_tests
import transaction_tests

def suite():
    return unittest.TestSuite((lowlevel_tests.suite(), api_tests.suite(),
           type_tests.suite(), userfunction_tests.suite(),
           transaction_tests.suite()))

def main():
    runner = unittest.TextTestRunner()
    runner.run(suite())
    
if __name__ == "__main__":
    main()
