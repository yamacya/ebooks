#!/usr/bin/python

import sqlite

conn = sqlite.connect(db="db", mode=077)
cursor = conn.cursor()

f_in = open('data.txt', 'r')

if f_in==None:
    sys.exit(1)

rowcount = 0;
while 1:

    # Read the next line
    line = f_in.readline()

    # Check for empty lines
    if len(line) == 0:
        break

    # Remove the newline character (and trailing whitespace)
    line = line.rstrip()

    # Split the record using | as delimiter
    fields = line.split("|")

    place_holders = ",".join(['%s']*60)

    SQL = "insert into calflora values(NULL, %s)" % place_holders
    cursor.execute(SQL, tuple(fields[1:-1]))
    print cursor.sql()

    if rowcount == 100:
        break

    rowcount += 1

f_in.close()
conn.commit()
conn.close()
