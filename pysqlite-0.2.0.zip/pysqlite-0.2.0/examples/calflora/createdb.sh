#!/bin/sh

sqlite db < data.sql
