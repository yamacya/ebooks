#!/usr/bin/env python

import sys,types,sqlite

conn = sqlite.connect(db="db", mode=077)
cursor = conn.cursor()

cursor.expected_types=[ int,str,str,str,str,str,str,str,str,str,str,str,int,str,
                        str,str,str,str,str,str,str,str,str,str,str,str,str,str,
                        str,int,int,str,str,str,str,str,str,str,str,str,str,str,
                        int,str,str,str,str,str,str,int,str,str,int,str,str,str,
                        int,str,str,str,str]

SQL = "select * from calflora order by calrecnum"

cursor.execute(SQL)

row = cursor.fetchone()

while row != None:

    for field in row:
        if type(field) != types.StringType:
            sys.stdout.write(repr(field))
        else:
            sys.stdout.write(field)

        sys.stdout.write('|')

    sys.stdout.write("\n")
    row = cursor.fetchone()

conn.close()
