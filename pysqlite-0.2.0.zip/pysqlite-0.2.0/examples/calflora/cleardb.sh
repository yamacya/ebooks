#!/bin/sh

echo "delete from calflora;" | sqlite db
