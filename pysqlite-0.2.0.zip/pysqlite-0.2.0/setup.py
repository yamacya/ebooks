#!/usr/bin/env python

import os, sys
from distutils.core import setup
from distutils.extension import Extension

sqlite = "sqlite"

if sys.platform in ("linux-i386", "linux2"): # most Linux
    include_dirs = ['/usr/include/sqlite']
    library_dirs = ['/usr/lib/']
    libraries = [sqlite]
    runtime_library_dirs = []
    extra_objects = []
elif sys.platform in ("freebsd4", "openbsd2"): 
    include_dirs = ['/usr/local/include/sqlite']
    library_dirs = ['/usr/local/lib/']
    libraries = [sqlite]
    runtime_library_dirs = []
    extra_objects = []
elif sys.platform == "sunos5": # Solaris 2.8 
    include_dirs = ['/usr/local/sqlite/include/sqlite'] 
    library_dirs = ['/usr/local/sqlite/lib/'] 
    libraries = [sqlite] 
    runtime_library_dirs = ['/usr/local/lib:/usr/openwin/lib:/usr/dt/lib'] 
    extra_objects = [] 
elif sys.platform == "win32":
    include_dirs = [r'..\sqlite']
    library_dirs = [r'..\sqlite']
    libraries = ["sqlite"]
    runtime_library_dirs = []
    extra_objects = []
elif sys.platform == "darwin1": # Mac OS X
    include_dirs = ['/usr/local/sqlite/include/sqlite']
    library_dirs = ['/usr/local/sqlite/lib/']
    libraries = [sqlite]
    runtime_library_dirs = []
    extra_objects = []
elif os.name == "posix": # most Linux/UNIX platforms
    include_dirs = ['/usr/include/sqlite']
    library_dirs = ['/usr/lib/sqlite']
    libraries = [sqlite]
    # On some platorms, this can be used to find the shared libraries
    # at runtime, if they are in a non-standard location. Doesn't
    # work for Linux gcc.
    ## runtime_library_dirs = library_dirs
    runtime_library_dirs = []
    # This can be used on Linux to force use of static sqlite lib
    ## extra_objects = ['/usr/lib/sqlite/libsqlite.a']
    extra_objects = []
else:
    raise "UnknownPlatform", "sys.platform=%s, os.name=%s" % \
          (sys.platform, os.name)
    
long_description = \
"""Python interface to SQLite

pysqlite is an interface to the SQLite database server for Python. It aims to be
fully compliant with Python database API version 2.0 while also exploiting the
unique features of SQLite.

"""

setup ( # Distribution meta-data
        name = "sqlite-python",
        version = "0.2.0",
        description = "An interface to SQLite",
        long_description=long_description,
        author = "Michael Owens",
        author_email = "mike@mikesclutter.com",
        license = "Python license",
        platforms = "ALL",
        url = "http://pysqlite.sourceforge.net/",

        # Description of the modules and packages in the distribution

        py_modules = ["pysqlite_exceptions",
                      "sqlite.main",
                      "sqlite.constants.FIELD_TYPE"
                      ],

        ext_modules = [Extension( name='_sqlite',
                                  sources=['_sqlite.c'],
                                  include_dirs=include_dirs,
                                  library_dirs=library_dirs,
                                  runtime_library_dirs=runtime_library_dirs,
                                  libraries=libraries,
                                  extra_objects=extra_objects
                                  )]
        )
