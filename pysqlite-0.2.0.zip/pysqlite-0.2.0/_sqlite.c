/*                                            _ _ _       
**                      _ __  _   _ ___  __ _| (_) |_ ___ 
**                     | '_ \| | | / __|/ _` | | | __/ _ \
**                     | |_) | |_| \__ \ (_| | | | ||  __/
**                     | .__/ \__, |___/\__, |_|_|\__\___|
**                     |_|    |___/        |_|            
**
**               A DB API v2.0 compatible interface to SQLite
**                       Embedded Relational Database.
**                          Copyright (c) 2001-2002
**                  Michael Owens <mike@mikesclutter.com>
**
** All Rights Reserved
**
** Permission to use, copy, modify, and distribute this software and its
** documentation for any purpose and without fee is hereby granted, provided
** that the above copyright notice appear in all copies and that both that
** copyright notice and this permission notice appear in supporting
** documentation,
**
** This program is distributed in the hope that it will be useful, but WITHOUT
** ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
** FOR A PARTICULAR PURPOSE.
*/

#include "Python.h"
#include "structmember.h"

#include "sqlite.h"

/*------------------------------------------------------------------------------
** Object Declarations
**------------------------------------------------------------------------------
*/

/** A connection object */
typedef struct
{
    PyObject_HEAD
    const char* database_name;
    const char* sql;
    sqlite* p_db;
} pysqlc;

/** A result set object. */
typedef struct
{
    PyObject_HEAD
    const char* database_name;
    const char* sql;
    PyObject* p_row_list;
    PyObject* p_col_def_list;
    int row_count;
} pysqlrs;

static PyObject* _sqlite_SQLiteError;
static PyObject* _sqlite_Warning;
static PyObject* _sqlite_Error;
static PyObject* _sqlite_DatabaseError;
static PyObject* _sqlite_InterfaceError; 
static PyObject* _sqlite_DataError;
static PyObject* _sqlite_OperationalError; 
static PyObject* _sqlite_IntegrityError; 
static PyObject* _sqlite_InternalError; 
static PyObject* _sqlite_ProgrammingError;
static PyObject* _sqlite_NotSupportedError;

/*------------------------------------------------------------------------------
** Function Prototypes
**------------------------------------------------------------------------------
*/

static int process_record(void* p_data, int num_fields, char** p_fields, char** p_col_names);

void init_sqlite(void);
static int _seterror(int returncode, char* errmsg);
static void _con_dealloc(pysqlc *self);
PyObject* pysqlite_connect(PyObject *self, PyObject *args, PyObject *kwargs);
static PyObject* sqlite_library_version(PyObject *self, PyObject *args);

/** Connection Object Methods */
static PyObject* _con_get_attr(pysqlc *self, char *attr);
static PyObject* _con_close(pysqlc *self, PyObject *args);
static PyObject* _con_begin(pysqlc *self, PyObject *args);
static PyObject* _con_commit(pysqlc *self, PyObject *args);
static PyObject* _con_rollback(pysqlc *self, PyObject *args);
static pysqlrs* _con_execute(pysqlc *self, PyObject *args);
static PyObject* _con_sql(pysqlc *self, PyObject *args);
static PyObject* _con_create_function(pysqlc *self, PyObject *args, PyObject *kwargs);
static PyObject* _con_create_aggregate(pysqlc *self, PyObject *args, PyObject *kwargs);

/** Result set Object Methods */
static void _rs_dealloc(pysqlrs* self);
static PyObject* _rs_get_attr(pysqlrs* self, char *attr);

PyTypeObject pysqlc_Type = 
{
    PyObject_HEAD_INIT(NULL)
    0,
    "connection",
    sizeof(pysqlc),
    0,
    (destructor) _con_dealloc,
    0,
    (getattrfunc) _con_get_attr,
    (setattrfunc) NULL,
};

PyTypeObject pysqlrs_Type = 
{
    PyObject_HEAD_INIT(NULL)
    0,
    "result_set",
    sizeof(pysqlrs),
    0,
    (destructor) _rs_dealloc,
    0,
    (getattrfunc) _rs_get_attr,
    (setattrfunc) NULL,
};

/*------------------------------------------------------------------------------
** Module Definitions / Initialization
**------------------------------------------------------------------------------
*/
static PyMethodDef pysqlite_functions[] =
{
    { "connect", (PyCFunction)pysqlite_connect, METH_VARARGS | METH_KEYWORDS},
    { "sqlite_version", (PyCFunction)sqlite_library_version, METH_VARARGS},
    { NULL, NULL }
};

static PyObject *
_sqlite_NewException( PyObject *dict, PyObject *edict, char *name)
{
    PyObject *e;

    if (!(e = PyDict_GetItemString(edict, name)))
    {
        return NULL;
    }

    if (PyDict_SetItemString(dict, name, e))
    {
        return NULL;
    }

    return e;
}

DL_EXPORT(void) init_sqlite()
{
    PyObject *module, *dict, *emod, *edict;

    pysqlc_Type.ob_type = &PyType_Type;
    pysqlrs_Type.ob_type = &PyType_Type;

    module = Py_InitModule("_sqlite", pysqlite_functions);

    if (!(dict = PyModule_GetDict(module)))
    {
        goto error;
    }

    /* Initialize exception objects */

    if (!(emod = PyImport_ImportModule("pysqlite_exceptions")))
        goto error;

    if (!(edict = PyModule_GetDict(emod))) goto error;

    if (!(_sqlite_SQLiteError = 
          _sqlite_NewException(dict, edict, "SQLiteError")))
        goto error;

    if (!(_sqlite_Warning =
          _sqlite_NewException(dict, edict, "Warning")))
        goto error;

    if (!(_sqlite_Error =
          _sqlite_NewException(dict, edict, "Error")))
        goto error;

    if (!(_sqlite_InterfaceError =
          _sqlite_NewException(dict, edict, "InterfaceError")))
        goto error;

    if (!(_sqlite_DatabaseError =
          _sqlite_NewException(dict, edict, "DatabaseError")))
        goto error;

    if (!(_sqlite_DataError =
          _sqlite_NewException(dict, edict, "DataError")))
        goto error;

    if (!(_sqlite_OperationalError =
          _sqlite_NewException(dict, edict, "OperationalError")))
        goto error;

    if (!(_sqlite_IntegrityError =
          _sqlite_NewException(dict, edict, "IntegrityError")))
        goto error;

    if (!(_sqlite_InternalError =
          _sqlite_NewException(dict, edict, "InternalError")))
        goto error;

    if (!(_sqlite_ProgrammingError =
          _sqlite_NewException(dict, edict, "ProgrammingError")))
        goto error;

    if (!(_sqlite_NotSupportedError =
          _sqlite_NewException(dict, edict, "NotSupportedError")))
        goto error;

    Py_DECREF(emod);

  error:

    if (PyErr_Occurred())
    {
        PyErr_SetString(PyExc_ImportError, "sqlite: init failed");
    }
}

/*------------------------------------------------------------------------------
** Connection Object Implementation
**------------------------------------------------------------------------------
*/

static struct memberlist _con_memberlist[] = 
{
    {"database", T_STRING, offsetof(pysqlc, database_name), RO},
    {NULL}
};

static PyMethodDef _con_methods[] = 
{
    {"close", (PyCFunction) _con_close, METH_VARARGS},
    {"begin", (PyCFunction) _con_begin, METH_VARARGS},
    {"commit", (PyCFunction) _con_commit, METH_VARARGS},
    {"rollback", (PyCFunction) _con_rollback, METH_VARARGS},
    {"execute",  (PyCFunction)_con_execute, METH_VARARGS},
    {"sql", (PyCFunction)_con_sql, METH_VARARGS},
    {"create_function", (PyCFunction)_con_create_function, METH_VARARGS | METH_KEYWORDS},
    {"create_aggregate", (PyCFunction)_con_create_aggregate, METH_VARARGS | METH_KEYWORDS},
    { NULL, NULL}
};

static void
_con_dealloc(pysqlc* self)
{
    if(self)
    {
        if(self->p_db != 0)
        {
            /* Close the database */
            sqlite_close(self->p_db);
            self->p_db = 0;
        }

        if(self->sql != NULL)
        {
            /* Free last SQL statment string */
            free((void*)self->sql);
            self->sql = NULL;
        }

        if(self->database_name != NULL)
        {
            /* Free database name string */
            free((void*)self->database_name);
            self->database_name = NULL;
        }

        PyObject_Del(self);
    }
}
    
/* return a new instance of sqlite_connection */
PyObject* pysqlite_connect(PyObject *self, PyObject *args, PyObject *kwargs)
{
    int ret;
    const char* db_name = 0;
    const char* host = 0;
    const char* user = 0;
    const char* password = 0;
    int mode = 0777;
    char *errmsg;

    pysqlc* obj;
    
    static char *kwlist[] = { "db", "mode", "user", "passwd", "host", NULL };

    ret = PyArg_ParseTupleAndKeywords(args, kwargs, "|sisss:psqlite_connect",
                                      kwlist, &db_name, &mode,
                                      &user, &password, &host);

    if(ret == 0)
    {
        return NULL;
    }
    
    if(db_name == 0)
    {
        return NULL;
    }
    
    obj = PyObject_New(pysqlc, &pysqlc_Type);

    if(obj)
    {
        /* Assign the database name */
        obj->database_name = strdup(db_name);

        /* Init sql string to NULL */
        obj->sql = NULL;

        /* Open the database */
        obj->p_db = sqlite_open(db_name, mode, &errmsg);

        if(obj->p_db == 0 || errmsg != NULL)
        {
            PyObject_Del(obj);
	    if (errmsg != NULL)
	    {
		PyErr_SetString(_sqlite_DatabaseError, errmsg);
		free(errmsg);
	    }
	    else
	    {
                PyErr_SetString(_sqlite_DatabaseError, "Could not open database.");
	    }
            return NULL;
        }
    }

    return (PyObject *) obj;
}

static PyObject* _con_get_attr(pysqlc *self, char *attr)
{
    PyObject *res;
    
    res = Py_FindMethod(_con_methods, (PyObject *) self,attr);

    if(NULL != res)
    {
        return res;
    }
    else
    {
        PyErr_Clear();
        return PyMember_Get((char *) self, _con_memberlist, attr);
    }
}

static PyObject* _con_close(pysqlc *self, PyObject *args)
{
    if (!PyArg_ParseTuple(args,"")) 
    {
        return NULL;
    }
    
    if(self->p_db != 0)
    {
        /* Close the database */
        sqlite_close(self->p_db);
        self->p_db = 0;
    }
    else
    {
        PyErr_SetString(_sqlite_ProgrammingError, "Database is not open.");
        return NULL;
    }

    Py_INCREF(Py_None);

    return Py_None;
}

static PyObject* _con_begin(pysqlc *self, PyObject *args)
{
    int ret;
    char *errmsg;

    if (!PyArg_ParseTuple(args,"")) 
    {
        return NULL;
    }

     if(self->p_db == 0)
    {
        /* There is no open database. */
        PyErr_SetString(_sqlite_ProgrammingError, "There is no open database.");
        return NULL;
    }

    ret = sqlite_exec( self->p_db, "BEGIN TRANSACTION;", (sqlite_callback)0,0, &errmsg);
    if (_seterror(ret, errmsg) != SQLITE_OK)
    {
        return NULL;
    }

    Py_INCREF(Py_None);

    return Py_None;
}

static PyObject* _con_commit(pysqlc *self, PyObject *args)
{
    int ret;
    char *errmsg;

    if (!PyArg_ParseTuple(args,"")) 
    {
        return NULL;
    }

     if(self->p_db == 0)
    {
        /* There is no open database. */
        PyErr_SetString(_sqlite_ProgrammingError, "There is no open database.");
        return NULL;
    }

    ret = sqlite_exec( self->p_db, "COMMIT TRANSACTION;",0,0, &errmsg);
    if (_seterror(ret, errmsg) != SQLITE_OK)
    {
        return NULL;
    }

    Py_INCREF(Py_None);

    return Py_None;
}

static PyObject* _con_rollback(pysqlc *self, PyObject *args)
{
    int ret;
    char *errmsg;

    if (!PyArg_ParseTuple(args,"")) 
    {
        return NULL;
    }

     if(self->p_db == 0)
    {
        /* There is no open database. */
        PyErr_SetString(_sqlite_ProgrammingError, "There is no open database.");
        return NULL;
    }

    ret = sqlite_exec( self->p_db, "ROLLBACK TRANSACTION;",0,0, &errmsg);
    
    if (_seterror(ret, errmsg) != SQLITE_OK)
    {
        return NULL;
    }

    Py_INCREF(Py_None);

    return Py_None;
}

static PyObject* _con_sql(pysqlc* self, PyObject *args)
{
    if (!PyArg_ParseTuple(args,"")) 
    {
        return NULL;
    }

     if(self->p_db == 0)
    {
        /* There is no open database. */
        PyErr_SetString(_sqlite_ProgrammingError, "There is no open database.");
        return NULL;
    }

     if(self->sql != NULL)
    {
        return Py_BuildValue("s", self->sql);
    }

    Py_INCREF(Py_None);
    return Py_None;
}

static void function_callback(sqlite_func *context, int argc, const char **argv)
{
    int i;
    PyObject* function_result;
    PyObject* args;
    PyObject* func;
    char* result_string;
    int result_int;
    double result_double;

    args = PyTuple_New(argc);
    for (i = 0; i < argc; i++)
    {
        PyTuple_SetItem(args, i, PyString_FromString(argv[i]));
    }

    func = (PyObject*)sqlite_user_data(context);
    function_result = PyObject_CallObject(func, args);
    if (PyErr_Occurred())
    {
        PyErr_Print();
        sqlite_set_result_error(context, NULL, -1);
        return;
    }

    /**
     * XXX Maybe it's better to return everything as string. This would elimi-
     *     nate to check for in/long overflows, for example. Additionally,
     *     we have the "pysqlite_pragma expected_types" feature for casting
     *     the function results afterwards.
     */
    if (PyInt_Check(function_result))
    {
        /* FIXME: overflow checking */
        result_int= (int)PyInt_AsLong(function_result);
        sqlite_set_result_int(context, result_int);
    }
    else if (PyFloat_Check(function_result))
    {
        result_double= PyFloat_AsDouble(function_result);

        sqlite_set_result_double(context, result_double);
    }
    else if (PyString_Check(function_result))
    {
        result_string = PyString_AsString(function_result);
        sqlite_set_result_string(context, result_string, -1);
    }
    else if (function_result == Py_None)
    {
        sqlite_set_result_string(context, NULL, -1);
    }
    else
    {
        PyErr_SetString(_sqlite_ProgrammingError,
                        "Illegal return type for user-defined function.");
    }

    Py_DECREF(function_result);
}

static void aggregate_step(sqlite_func *context, int argc, const char **argv)
{
    int i;
    PyObject* userdata;
    PyObject* func;
    PyObject* args;
    PyObject* function_result;

    userdata = (PyObject*)sqlite_user_data(context);
    func = PyTuple_GetItem(userdata, 0);

    args = PyTuple_New(argc);
    for (i = 0; i < argc; i++)
    {
        if (argv[i] == NULL)
        {
            PyTuple_SetItem(args, i, Py_None);
        }
        else
        {
            PyTuple_SetItem(args, i, PyString_FromString(argv[i]));
        }
    }

    if (PyErr_Occurred())
    {
        PyErr_Print();
    }

    function_result = PyObject_CallObject(func, args);
    if (function_result == NULL)
    {
        PyErr_Print();
        /* Don't use sqlite_set_result_error here. Else an assertion in
         * the SQLite code will trigger and create a core dump.
         */
    }
    else
    {
        Py_DECREF(function_result);
    }
}

static void aggregate_finalize(sqlite_func *context)
{
    PyObject* userdata;
    PyObject* func;
    PyObject* args;
    PyObject* function_result;
    char* result_string;
    int result_int;
    double result_double;

    userdata= (PyObject*)sqlite_user_data(context);

    func = PyTuple_GetItem(userdata, 1);
    args = PyTuple_New(0);
    function_result = PyObject_CallObject(func, args);
    Py_DECREF(args);
    
    if (PyErr_Occurred())
    {
        PyErr_Print();
        sqlite_set_result_error(context, NULL, -1);
        return;
    }

    /* XXX see XXX comment in function_callback about type conversion */
    if (PyInt_Check(function_result))
    {
        /* FIXME: overflow checking */
        result_int= (int)PyInt_AsLong(function_result);
        sqlite_set_result_int(context, result_int);
    }
    else if (PyFloat_Check(function_result))
    {
        result_double= PyFloat_AsDouble(function_result);

        sqlite_set_result_double(context, result_double);
    }
    else if (PyString_Check(function_result))
    {
        result_string = PyString_AsString(function_result);
        sqlite_set_result_string(context, result_string, -1);
    }
    else if (function_result == Py_None)
    {
        sqlite_set_result_string(context, NULL, -1);
    }
    else
    {
        PyErr_SetString(_sqlite_ProgrammingError,
                        "Illegal return type for user-defined aggregate.");
    }

    Py_DECREF(function_result);
}

static PyObject* _con_create_function(pysqlc* self, PyObject *args, PyObject* kwargs)
{
    int ret;
    int n_args;
    char* name;
    PyObject* func;
    static char *kwlist[] = {"name", "n_args", "func", NULL};

    ret = PyArg_ParseTupleAndKeywords(args, kwargs, "|siO:psqlite_create_function",
                                      kwlist, &name, &n_args,
                                      &func);

    if (ret == 0)
    {
        return NULL;
    }

    Py_INCREF(func);
    ret = sqlite_create_function(self->p_db, name, n_args, &function_callback, (void*)func);
 
    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject* _con_create_aggregate(pysqlc* self, PyObject *args, PyObject* kwargs)
{
    PyObject* callbacks;
    PyObject* step;
    PyObject* finalize;

    int ret;
    int n_args;
    char* name;
    static char *kwlist[] = { "name", "n_args", "step_func", "finalize_func", "user_data", NULL };

    ret = PyArg_ParseTupleAndKeywords(args, kwargs, "|siOOO:psqlite_aggregate",
                                      kwlist, &name, &n_args,
                                      &step, &finalize);
    if (ret == 0)
    {
        return NULL;
    }

    callbacks = PyTuple_New(2);
    Py_INCREF(step);
    Py_INCREF(finalize);
    PyTuple_SetItem(callbacks, 0, step);
    PyTuple_SetItem(callbacks, 1, finalize);

    sqlite_create_aggregate(self->p_db, name, n_args, &aggregate_step, &aggregate_finalize, (void*)callbacks);

    Py_INCREF(Py_None);
    return Py_None;
}

static PyObject * sqlite_library_version(PyObject *self, PyObject *args)
{
    if (!PyArg_ParseTuple(args, ""))
    {
        return NULL;
    }
    
    return Py_BuildValue("s", sqlite_libversion());
}

static int _seterror(int returncode,  char *errmsg)
{
    switch (returncode)
    {
        case SQLITE_OK:
            PyErr_Clear();
            break;
        case SQLITE_ERROR:
            PyErr_SetString(_sqlite_DatabaseError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_INTERNAL:
            PyErr_SetString(_sqlite_InternalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_PERM:
            PyErr_SetString(_sqlite_OperationalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_ABORT:
            PyErr_SetString(_sqlite_OperationalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_BUSY:
            PyErr_SetString(_sqlite_OperationalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_LOCKED:
            PyErr_SetString(_sqlite_OperationalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_NOMEM:
            (void)PyErr_NoMemory();
            break;
        case SQLITE_READONLY:
            PyErr_SetString(_sqlite_DatabaseError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_INTERRUPT:
            PyErr_SetString(_sqlite_OperationalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_IOERR:
            PyErr_SetString(_sqlite_OperationalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_CORRUPT:
            PyErr_SetString(_sqlite_DatabaseError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_NOTFOUND:
            PyErr_SetString(_sqlite_InternalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_FULL:
            PyErr_SetString(_sqlite_DatabaseError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_CANTOPEN:
            PyErr_SetString(_sqlite_DatabaseError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_PROTOCOL:
            PyErr_SetString(_sqlite_OperationalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_EMPTY:
            PyErr_SetString(_sqlite_InternalError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_SCHEMA:
            PyErr_SetString(_sqlite_DatabaseError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_TOOBIG:
            PyErr_SetString(_sqlite_DataError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_CONSTRAINT:
            PyErr_SetString(_sqlite_IntegrityError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
        case SQLITE_MISMATCH:
            PyErr_SetString(_sqlite_IntegrityError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
#ifdef SQLITE_MISUSE
        case SQLITE_MISUSE:
            PyErr_SetString(_sqlite_ProgrammingError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
            break;
#endif
        default:
            PyErr_SetString(_sqlite_DatabaseError, (errmsg!=NULL)?errmsg:sqlite_error_string(returncode));
    }
    free(errmsg);
    return returncode;
}

static pysqlrs* _con_execute(pysqlc* self, PyObject *args)
{
    int i;
    int ret;
    int record_number;
    int num_fields;
    const char* sql;
    pysqlrs* p_rset;
    PyObject* p_col_def_list;
    PyObject* p_col_def_tup;
    char *errmsg;
    record_number = 0;

    if(!PyArg_ParseTuple(args,"s:execute", &sql))
    {
        return NULL;
    }
    
    /* Save the SQL */
    self->sql = strdup(sql);

    if(self->p_db == 0)
    {
        /* There is no open database. */
        PyErr_SetString(_sqlite_ProgrammingError, "There is no open database.");
        return NULL;
    }

    p_rset = PyObject_New(pysqlrs, &pysqlrs_Type);
    ((pysqlrs*)p_rset)->p_row_list = PyList_New(0);
    ((pysqlrs*)p_rset)->p_col_def_list = PyList_New(0);
    ((pysqlrs*)p_rset)->row_count = 0;

    /* Run a query: process_record is called back for each record returned. */
    ret = sqlite_exec( self->p_db,
                       sql,
                       process_record,
                       p_rset,
                       &errmsg);

    /* Maybe there occurred an error in a user-defined function */
    if (PyErr_Occurred())
    {
        return NULL;
    }

    if(_seterror(ret, errmsg) != SQLITE_OK)
    {
        return NULL;
    }

    /* Convert Column definitions from lists to tuples */
    num_fields = PyList_Size(p_rset->p_col_def_list);

    for(i=0; i < num_fields; i++)
    {
        /* Get the column def. */
        p_col_def_list = PyList_GetItem(p_rset->p_col_def_list, i);

        /* Get it into the form of a tuple. */
        p_col_def_tup = PyList_AsTuple(p_col_def_list);

        /* Put the tuple in its place. */
        PyList_SetItem(p_rset->p_col_def_list, i, p_col_def_tup);
    }

    return p_rset;
}

int process_record(void* p_data, int num_fields, char** p_fields, char** p_col_names)
{
    int i;
    int field_size;
    int max_field_size;
    pysqlrs* p_rset;
    PyObject* p_row;
    PyObject* p_col_def;

    p_rset = (pysqlrs*)p_data;

    /* Create a row */
    p_row = PyTuple_New(num_fields);

    if(p_rset->row_count == 0)
    {
        for (i=0; i < num_fields; i++)
        {
            p_col_def = PyList_New(7);

            /* 1. Column Name */
            PyList_SetItem(p_col_def, 0, Py_BuildValue("s", p_col_names[i]));

            /* 2. Type code: Always set as field_type.TEXT */
            PyList_SetItem(p_col_def, 1, Py_BuildValue("i", 254));

            /* 3. Display Size */
            PyList_SetItem(p_col_def, 2, Py_BuildValue("i", 0));

            /* 4. Internal Size */
            PyList_SetItem(p_col_def, 3, Py_BuildValue("i", 0));

            /* 5. Precision */
            PyList_SetItem(p_col_def, 4, Py_BuildValue("i", 0));

            /* 6. Scale */
            PyList_SetItem(p_col_def, 5, Py_BuildValue("i", 0));

            /* 7. NULL Okay */
            PyList_SetItem(p_col_def, 6, Py_BuildValue("i", 1));

            PyList_Append(p_rset->p_col_def_list, p_col_def);
        }
    }

    p_rset->row_count++;

    for (i=0; i < num_fields; i++)
    {
        /* Store the field value */
        if(p_fields[i] != 0)
        {
            PyTuple_SetItem(p_row, i, Py_BuildValue("s", p_fields[i]));
        }
        else
        {
            /* A NULL field */
            Py_INCREF(Py_None);
            PyTuple_SetItem(p_row, i, Py_None);
        }

        /* See if the field's width is larger than the max_field_width */
        if(p_fields[i] != 0)
        {
            p_col_def = PyList_GetItem(p_rset->p_col_def_list, i);

            max_field_size = PyInt_AsLong(PyList_GetItem(p_col_def, 2));
            
            field_size = strlen(p_fields[i]);
            
            if(field_size > max_field_size)
            {
                PyList_SetItem(p_col_def, 2, PyInt_FromLong(field_size));
                PyList_SetItem(p_col_def, 3, PyInt_FromLong(field_size));
            }
        }
    }

    PyList_Append(p_rset->p_row_list, p_row);

    return 0;
}

/*------------------------------------------------------------------------------
** Result Set Object Implementation
**------------------------------------------------------------------------------
*/

static struct memberlist _rs_memberlist[] = 
{
    {"row_list", T_OBJECT, offsetof(pysqlrs, p_row_list),     RO},
    {"col_defs", T_OBJECT, offsetof(pysqlrs, p_col_def_list), RO},
    {"rowcount", T_INT, offsetof(pysqlrs, row_count),         RO},
    {NULL}
};

static PyMethodDef _rs_methods[] = 
{
    { NULL, NULL}
};

static void
_rs_dealloc(pysqlrs* self)
{
    if(self)
    {
        if(self->p_row_list != 0)
        {
            Py_DECREF(self->p_row_list);

            self->p_row_list = 0;
        }

        if(self->p_col_def_list != 0)
        {
            Py_DECREF(self->p_col_def_list);

            self->p_col_def_list = 0;
        }

        PyObject_Del(self);
    }
}

static PyObject* _rs_get_attr(pysqlrs *self, char *attr)
{
    PyObject *res;
    
    res = Py_FindMethod(_rs_methods, (PyObject *) self,attr);

    if(NULL != res)
    {
        return res;
    }
    else
    {
        PyErr_Clear();
        return PyMember_Get((char *) self, _rs_memberlist, attr);
    }
}

