# These are various field types, which really aren't supported by SQLite, but
# perhaps there will be a way to evenutually coerce them based on SQLite's
# schema.

SHORT      = 1
LONG       = 2
FLOAT      = 3
DOUBLE     = 4
NULL       = 5
TIMESTAMP  = 6
DATE       = 7
TIME       = 8
DATETIME   = 9
BLOB       = 10
VAR_STRING = 11
STRING     = 12
CHAR       = STRING
TEXT       = 254
