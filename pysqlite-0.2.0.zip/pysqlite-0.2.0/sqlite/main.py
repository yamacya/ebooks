from __future__ import nested_scopes
import _sqlite

import copy, new, re, string, sys, weakref
from types import ListType, TupleType, DictType, StringType, UnicodeType

EXPECTED_TYPES_REGEX = re.compile(r"\s*pysqlite_pragma\s*expected_types\s*=(.*)")
RESET_EXPECTED_TYPES_REGEX = re.compile(r"\s*pysqlite_pragma\s*reset_expected_types")

def _quote(value):
    """
_quote(value) -> string
    This function transforms the Python value into a string suitable to send
    to the PostgreSQL database in a insert or update statement.  This function
    is automatically applied to all parameter sent vis an execute() call.
    Because of this an update/insert statement string in an execute() call
    should only use '%s' [or '%(name)s'] for variable subsitution without any
    quoting."""

    if value is None:
        return 'NULL'

    if hasattr(value, '_quote'):
        return value._quote()

    #if type(value) in [DateTimeType, DateTimeDeltaType]:
    #    return "'%s'" % value

    if isinstance(value, StringType):
        return "'%s'" % re.sub("'", "''", value)

    return repr(value)

def _quoteall(vdict):
    """
_quoteall(vdict)->dict
    Quotes all elements in a list or dictionary to make them suitable for
    insertion."""

    if type(vdict) is DictType or isinstance(vdict, PgResultSet):
        t = {}
        for k, v in vdict.items():
            t[k]=_quote(v)
    elif isinstance(vdict, StringType) or isinstance(vdict, UnicodeType):
        # Note: a string is a SequenceType, but is treated as a single
        #    entity, not a sequence of characters.
        t = (_quote(vdict), )
    elif type(vdict)in [ListType, TupleType]:
        t = tuple(map(_quote, vdict))
    else:
        raise TypeError, \
              "argument to _quoteall must be a sequence or dictionary!"

    return t

class DBAPITypeObject:
    def __init__(self,*values):
        self.values = values

    def __cmp__(self,other):
        if other in self.values:
            return 0
        if other < self.values:
            return 1
        else:
            return -1

#-----------------------------------------------------------------------+
# Name: PgResultSet                                                     |
#                                                                       |
# Description: This class defines the DB-API query result set for a     |
#        single row.  It emulates a sequence  with the added            |
#        feature of being able to reference an attribute by             |
#        column name in addition to a zero-based numeric index.         |
#-----------------------------------------------------------------------+

def make_PgResultSetClass(description):
    NewClass = new.classobj("PgResultSetConcreteClass", (PgResultSet,), {})
    NewClass.__dict__['_desc_'] = description

    NewClass.__dict__['_xlatkey'] = {}

    for _i in range(len(description)):
        NewClass.__dict__['_xlatkey'][description[_i][0]] = _i

    return NewClass

class PgResultSet:
    def __init__(self, value):
        self.__dict__['baseObj'] = value
    
    def __getattr__(self, key):
        if self.__class__._xlatkey.has_key(key):
            return self.baseObj[self.__class__._xlatkey[key]]
        raise AttributeError, key

    # We define a __setattr__ routine that will only allow the attributes that
    # are the column names to be updated.  All other attributes are read-only.
    def __setattr__(self, key, value):
        if key in ('baseObj'):
            raise AttributeError, "%s is read-only." % key

        if self.__class__._xlatkey.has_key(key):
            self.__dict__['baseObj'][self.__class__._xlatkey(key)] = value
        else:
            raise AttributeError, key

    def __len__(self):
        return len(self.baseObj)

    def __getitem__(self, key):
        if isinstance(key, StringType):
            key = self.__class__._xlatkey[key]
        return self.baseObj[key]

    def __setitem__(self, key, value):
        if isinstance(key, StringType):
            key = self.__class__._xlatkey[key]

        self.baseObj[key] = value

    def __getslice__(self, i, j):
        klass = make_PgResultSetClass(self.__class__._desc_[i:j])
        obj = klass(self.baseObj[i:j])
        return obj

    def __repr__(self):
        return repr(self.baseObj)

    def __str__(self):
        return str(self.baseObj)

    def __cmp__(self, other):
        return cmp(self.baseObj, other)

    def description(self):
        return _desc_

    def keys(self):
        _k = []
        for _i in _desc_:
            _k.append(_i[0])
        return _k

    def values(self):
        return self.baseObj[:]

    def items(self):
        _items = []
        for i in range(len(self.baseObj)):
            _items.append((_desc_[i][0], self.baseObj[i]))

        return _items

    def has_key(self, key):
        return self.__class__._xlatkey.has_key(key)

    def get(self, key):
        return self[key]

class Cursor:
    
    def __init__(self, con):
        self.arraysize = 1
        self.__reset()

        self.con = weakref.proxy(con)

	if not self.con.autocommit:
	    # Only the first created cursor begins the transaction.
	    if not self.con.inTransaction:
		con._Connection__begin()
                con.inTransaction = 1

    # Non API Functions
    def __reset(self):
	self.__dict__["res"]	     = None
	# closed is a trinary variable:
	#     == None => Cursor has not been opened.
	#     ==    0 => Cursor is open.
	#     ==    1 => Cursor is closed.
        self.rs = None
        self.rowcount = -1
        self.current_recnum = 0
        self.closed = None
        self.description = None
        self.expected_types = None

    def sql(self):
        return self.con.db.sql()

    def __unicodeConvert(self, obj):
        if isinstance(obj, StringType):
            return obj
        elif isinstance(obj, UnicodeType):
            return obj.encode(*self.con.client_encoding)
        elif isinstance(obj, ListType) or isinstance(obj, TupleType):
            converted_obj = []
            for item in obj:
                if type(item) is UnicodeType:
                    converted_obj.append(item.encode(*self.con.client_encoding))
                else:
                    converted_obj.append(item)
            return converted_obj
        elif isinstance(obj, DictType):
            converted_obj = {}
            for k, v in obj.items():
                if type(v) is UnicodeType:
                    converted_obj[k] = v.encode(*self.con.client_encoding)
                else:
                    converted_obj[k] = v
            return converted_obj
        elif isinstance(obj, PgResultSet):
            obj = copy.copy(obj)
            for k, v in obj.items():
                if type(v) is UnicodeType:
                    obj[k] = v.encode(*self.con.client_encoding)
            return obj
        else:
            return obj
    
    def __makedesc__(self):
        # Since __makedesc__ will only be called after a successful query or
        # fetch, self.res will contain the information needed to build the
        # description attribute even if no rows were returned.  So, we always
        # build up the description.
        self.description = self.rs.col_defs
        self.PgResultSetClass = make_PgResultSetClass(self.description[:])

    def _convert_types(self, l):
        def converter_wrapper(cvt, value, typeName):
            if value is None:
                return value
            else:
                try:
                    rv = cvt(value)
                except ValueError:
                    raise _sqlite.InterfaceError, \
                        "Conversion failed for value '%s' of expected type '%s'"%(str(value),typeName)
                return rv

        if self.expected_types is None:
            return l

        if l is None:
            return None
        elif isinstance(l, TupleType):
            return [converter_wrapper(cvt, item, typeName) \
                    for (cvt, typeName), item in zip(self.expected_types, l)]
        else:
            return l

    # API Functions
    def execute(self, SQL, *parms):
        if self.closed:
            raise _sqlite.ProgrammingError, \
                  "execute failed - the cursor is closed."

        if RESET_EXPECTED_TYPES_REGEX.match(SQL):
            self.expected_types = None
            return

        expected_types = EXPECTED_TYPES_REGEX.findall(SQL)
        if len(expected_types) == 1:
            self.expected_types = map(string.strip, expected_types[0].split(","))
            try:
                self.expected_types = [(self.con.converters[t],t) \
                                       for t in self.expected_types]
            except KeyError, key:
                raise _sqlite.InterfaceError, \
                    "execute failed - undefined expected type: '%s'"%key
            return
        
        if self.con.autocommit:
            pass
        else:
            if not self.con.inTransaction:
                self.con._Connection__begin()
                self.con.inTransaction = 1

        SQL = self.__unicodeConvert(SQL)
        if len(parms) == 0:
            # If there are no paramters, just execute the query.
            self.rs = self.con.db.execute(SQL)
        else:
            if len(parms) == 1 and \
               (type(parms[0]) in [DictType, ListType, TupleType] or \
                        isinstance(parms[0], PgResultSet)):
                parms = (self.__unicodeConvert(parms[0]),)
                parms = _quoteall(parms[0])
            else:
                parms = self.__unicodeConvert(parms)
                parms = tuple(map(_quote, parms));

            self.rs = self.con.db.execute(SQL % parms)
            
        self.closed = 0
        self.current_recnum = 0
        self.rowcount = len(self.rs.row_list)
        self.__makedesc__()

    def executemany(self, query, parm_sequence):
        if self.closed:
            raise _sqlite.ProgrammingError, \
                  "executemany failed - the cursor is closed."
        if self.con is None:
            raise Error, "connection is closed."

        for _i in parm_sequence:
            self.execute(query, _i)

    def fetchone(self):
        if self.closed:
            raise _sqlite.ProgrammingError, \
                  "fetchone failed - the cursor is closed."

        # If there are no records
        if self.rowcount == 0:
            return ()
            #raise _sqlite.InterfaceError, \
            #    "fetchone failed - no records returned by execute."

        # If we have reached the last record
        if(self.current_recnum == self.rowcount):
            return None

        retval = self.PgResultSetClass(
            self._convert_types(self.rs.row_list[self.current_recnum]))

        self.current_recnum += 1

        return retval

    def fetchmany(self, howmany):
        if self.closed:
            raise _sqlite.ProgrammingError, \
                  "fetchmany failed - the cursor is closed."

        # If there are no records
        if self.rowcount == 0:
            return ()
            #raise _sqlite.InterfaceError, \
             #   "fetchmany failed - no records returned by execute."
                

        # If we have reached the last record
        if(self.current_recnum >= self.rowcount):
            return ()

        retval = [self.PgResultSetClass(self._convert_types(item)) \
                  for item in self.rs.row_list[self.current_recnum: \
                                               self.current_recnum + howmany]]

        self.current_recnum += howmany

        return retval

    def fetchall(self):
        if self.closed:
            raise _sqlite.ProgrammingError, \
                  "fetchall failed - the cursor is closed."

        # If there are no records
        if self.rowcount == 0:
            return ()
            #raise _sqlite.InterfaceError, \
            #    "fetchall failed - no records returned by execute."

        # If we have reached the last record
        if(self.current_recnum >= self.rowcount):
            return ()

        retval = [self.PgResultSetClass(self._convert_types(item)) \
                  for item in self.rs.row_list[self.current_recnum:]]

        self.current_recnum = self.rowcount

        return retval

    def __getattr__(self, key):
        if Cursor.__dict__.has_key(key):
            return Cursor.__dict__[key]
        elif key == 'description':
            if self.rs:
                return self.rs.col_defs
            else:
                return None
        else:
            raise AttributeError, key

    # I don't understand what these two functions, as prescibed by the API,
    # are supposed to do, but fortunately the spec allows for implementors to do
    # nothing. That's what I'll do then.

    def setinputsizes(self, sizes):
        if self.closed:
            raise _sqlite.InterfaceError, \
                  "setinputsize failed - the cursor is closed."

    def setoutputsize(self, size, column=None):
        if self.closed:
            raise _sqlite.InterfaceError, \
                  "setoutputsize failed - the cursor is closed."

    def close(self):
        if self.con and self.con.isClosed:
            raise _sqlite.InterfaceError, \
                  "This cursor's connection is already closed."
        if self.closed:
            raise _sqlite.InterfaceError, \
                  "This cursor is already closed."
        self.closed = 1

class UnicodeConverter:
    def __init__(self, encoding):
        self.encoding = encoding

    def __call__(self, val):
        return unicode(val, *self.encoding)

class Connection:

    def __init__(self, db, mode=0755, converters={}, autocommit=0, client_encoding=None, *arg, **kwargs):
        if type(client_encoding) not in (TupleType, ListType):
            self.client_encoding = (client_encoding or sys.getdefaultencoding(),)
        else:
            self.client_encoding = client_encoding

        self.converters = {"str": str, "int": int, "long": long, "float": float}
        self.converters.update({"unicode": UnicodeConverter(self.client_encoding)})
        self.converters.update(converters)

        self.autocommit = autocommit

        self.db = _sqlite.connect(db, mode)
        self.isClosed = 0
        self.inTransaction = 0

        self.cursors = weakref.WeakValueDictionary()
        
    def __del__(self):
        if not self.isClosed:
            self.close()

    def __anyCursorsLeft(self):
	return len(self.cursors.data.keys()) > 0

    def __closeCursors(self, doclose=0):
	"""
	__closeCursors() - closes all cursors associated with this connection"""
	if self.__anyCursorsLeft():
	    cursors = map(lambda x: x(), self.cursors.data.values())

	    for cursor in cursors:
		if flag:
		    cursor.close()
		else:
		    cursor._Cursor__reset()

    # Non-API Functions
    def __begin(self):
        self.db.begin()
        self.inTransaction = 1

    def create_function(self, name, nargs, func):
        self.db.create_function(name, nargs, func)

    def create_aggregate(self, name, nargs, agg_class):
        agg = agg_class()
        stepfunc = lambda *args: agg_class.step(agg, *args)
        finfunc = lambda *args:  agg_class.finalize(agg, *args)
        self.db.create_aggregate(name, nargs, stepfunc, finfunc)

    # API Functions
    def commit(self):
	if self.isClosed:
	    raise _sqlite.ProgrammingError, "Commit failed - Connection is not open."

	if self.autocommit:
	    raise _sqlite.ProgrammingError, "Commit failed - autocommit is on."

        self.db.commit()
        self.inTransaction = 0

    def rollback(self):
	if self.isClosed:
	    raise _sqlite.ProgrammingError, "Rollback failed - Connection is not open."

	if self.autocommit:
	    raise _sqlite.ProgrammingError, "Rollback failed - autocommit is on."

        self.db.rollback()
        self.inTransaction = 0

    def close(self):
        if self.isClosed:
            raise _sqlite.InterfaceError, \
                  "Connection already closed."

        self.__closeCursors(1)
        
        if self.inTransaction:
            self.rollback()

        self.db.close()
        self.isClosed = 1

    def cursor(self):
        if self.isClosed:
            raise _sqlite.InterfaceError, \
                  "Connection is closed."

        return Cursor(self);
